# WineLib map outlines (2026-10-26)

- **inao**: INAO, Délimitation parcellaire des AOC viticoles. Licence Ouverte 2.0 (Etalab). https://www.data.gouv.fr
- **vineyard**: INAO, premiers crus (délimitation parcellaire). Licence Ouverte 2.0 (Etalab). https://www.data.gouv.fr
